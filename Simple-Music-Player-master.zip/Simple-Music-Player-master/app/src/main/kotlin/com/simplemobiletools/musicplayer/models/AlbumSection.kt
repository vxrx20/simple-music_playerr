package com.simplemobiletools.musicplayer.models

data class AlbumSection(val title: String) : ListItem()
