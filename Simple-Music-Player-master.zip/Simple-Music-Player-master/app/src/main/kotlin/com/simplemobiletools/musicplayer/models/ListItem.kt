package com.simplemobiletools.musicplayer.models

open class ListItem
