package com.simplemobiletools.musicplayer.interfaces

interface PlaybackSpeedListener {
    fun updatePlaybackSpeed(speed: Float)
}
